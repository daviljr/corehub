# LegadoCore — Render Ready (Node 18) — Backend + Dashboard

This project is prepared to deploy on Render (free tier) as a single web service.

How to deploy:
1. Create a GitHub repository and push this project (recommended).
2. On Render, create a new Web Service -> Connect to your repo -> Render will run:
   build: `npm install`
   start: `npm start`
3. Set environment variable `ADMIN_PASSWORD` (recommended) in Render dashboard (Service > Environment).
4. Optional: set `PORT` (default 10000 on Render); server respects `process.env.PORT`.

Local test:
```bash
npm install
NODE_ENV=development npm start
```

Endpoints:
- GET /api/health
- GET /api/modules
- POST /api/modules (body: {name, code})
- GET /api/modules/:name/run
- POST /api/sales (body: {client, amount, note})
- GET /api/sales
- Admin dashboard: GET /admin  (protected by ADMIN_PASSWORD query ?password=...)
